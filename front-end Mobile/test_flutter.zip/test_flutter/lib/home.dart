import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:test_flutter/api.dart';
import 'global.dart' as global;

class HomeWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Test',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Test'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String _timeString;

  @override
  void initState() {
    _timeString = _formatDateTime(DateTime.now());
    Timer.periodic(Duration(seconds: 1), (Timer t) => _getTime());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
            Text(_timeString),
            SizedBox(
              height: 25,
            ),
            InkWell(
                onTap: () async {
                  // Navigator.of(context).pushNamed('/Login');
                  BuildContext dialogContext;
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        dialogContext = context;
                        return AlertDialog(
                          title: Text('Mohon tunggu'),
                          content: LinearProgressIndicator(),
                        );
                      });
                  var res = await cek_status(global.username);
                  Navigator.pop(dialogContext);

                  if (res != 'gagal') {
                    var jam = res['login_time'].substring(0, 2);
                    var menit = res['login_time'].substring(2, 4);
                    var detik = res['login_time'].substring(4, 6);

                    var loginTime = jam + ':' + menit + ':' + detik;

                    return showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          dialogContext = context;
                          return AlertDialog(
                            title: Text('Pesan'),
                            content: Text('Hai ' +
                                res['username'] +
                                ', waktu login anda ' +
                                loginTime),
                          );
                        });
                  } else {
                    Navigator.of(context).pushNamed('/Login');
                  }
                },
                child: Text(
                  'Hello',
                  style: TextStyle(
                      fontSize: 20, backgroundColor: Colors.lightBlue),
                )),
          ])),
    );
  }

  void _getTime() {
    final DateTime now = DateTime.now();
    final String formattedDateTime = _formatDateTime(now);
    setState(() {
      _timeString = formattedDateTime;
    });
  }

  String _formatDateTime(DateTime dateTime) {
    return DateFormat('hh:mm:ss').format(dateTime);
  }
}
