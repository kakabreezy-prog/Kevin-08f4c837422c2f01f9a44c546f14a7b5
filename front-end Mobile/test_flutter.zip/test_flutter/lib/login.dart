import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:test_flutter/api.dart';
import 'global.dart' as global;

class LoginWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Test',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(title: 'Flutter Test'),
    );
  }
}

class LoginPage extends StatefulWidget {
  LoginPage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  LoginState createState() => LoginState();
}

class LoginState extends State<LoginPage> {
  String _timeString;

  @override
  void initState() {
    _timeString = _formatDateTime(DateTime.now());
    Timer.periodic(Duration(seconds: 1), (Timer t) => _getTime());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var userController = TextEditingController();
    var passController = TextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
            new TextField(
              controller: userController,
              keyboardType: TextInputType.text,
              decoration: new InputDecoration(
                hintText: 'Masukkan Username',
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                prefixIcon: Icon(
                  Icons.person,
                ),
              ),
            ),
            new TextField(
              controller: passController,
              keyboardType: TextInputType.visiblePassword,
              decoration: new InputDecoration(
                hintText: 'Masukkan Password',
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                prefixIcon: Icon(
                  Icons.lock,
                ),
              ),
            ),
            FlatButton(
              color: Colors.lightBlue,
              // textColor: Color(0xFF6200EE),
              onPressed: () async {
                BuildContext dialogContext;
                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      dialogContext = context;
                      return AlertDialog(
                        title: Text('Mohon tunggu'),
                        content: LinearProgressIndicator(),
                      );
                    });
                var res = await login(userController.text, passController.text);
                Navigator.pop(dialogContext);
                print(res);
                // return showDialog(
                //     context: context,
                //     builder: (BuildContext context) {
                //       return AlertDialog(
                //         title: Text('Message'),
                //         content: Text('Hi'),
                //       );
                //     });
              }
              // Navigator.of(context).pushNamed('/Login');
              // Respond to button press
              ,
              child: Text("Login"),
            ),
            FlatButton(
              color: Colors.lightBlue,
              // textColor: Color(0xFF6200EE),
              onPressed: () async {
                BuildContext dialogContext;
                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      dialogContext = context;
                      return AlertDialog(
                        title: Text('Mohon tunggu'),
                        content: LinearProgressIndicator(),
                      );
                    });
                var res = await login(userController.text, passController.text);
                Navigator.pop(dialogContext);
                if (res != 'Sukses') {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        dialogContext = context;
                        return AlertDialog(
                          title: Text('Mohon tunggu'),
                          content: Text(res),
                        );
                      });
                  ;
                } else {
                  global.username = userController.text;
                  Navigator.of(context).pushNamed('/');
                }
              }
              // Navigator.of(context).pushNamed('/Login');
              // Respond to button press
              ,
              child: Text("Register"),
            )
          ])),
    );
  }

  void _getTime() {
    final DateTime now = DateTime.now();
    final String formattedDateTime = _formatDateTime(now);
    setState(() {
      _timeString = formattedDateTime;
    });
  }

  String _formatDateTime(DateTime dateTime) {
    return DateFormat('hh:mm:ss').format(dateTime);
  }
}
