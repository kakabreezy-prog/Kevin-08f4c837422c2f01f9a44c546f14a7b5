import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:test_flutter/api.dart';
import 'global.dart' as global;

class RegisterWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Test',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: RegisterPage(title: 'Flutter Test'),
    );
  }
}

class RegisterPage extends StatefulWidget {
  RegisterPage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  RegisterState createState() => RegisterState();
}

class RegisterState extends State<RegisterPage> {
  String _timeString;

  @override
  void initState() {
    _timeString = _formatDateTime(DateTime.now());
    Timer.periodic(Duration(seconds: 1), (Timer t) => _getTime());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var userController = TextEditingController();
    var passController = TextEditingController();
    var passController2 = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
            new TextField(
              controller: userController,
              keyboardType: TextInputType.text,
              decoration: new InputDecoration(
                hintText: 'Masukkan Username',
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                prefixIcon: Icon(
                  Icons.person,
                ),
              ),
            ),
            new TextField(
              controller: passController,
              keyboardType: TextInputType.visiblePassword,
              decoration: new InputDecoration(
                hintText: 'Masukkan Password',
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                prefixIcon: Icon(
                  Icons.lock,
                ),
              ),
            ),
            new TextField(
              controller: passController2,
              keyboardType: TextInputType.visiblePassword,
              decoration: new InputDecoration(
                hintText: 'Ulangi Password',
                enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.blue)),
                prefixIcon: Icon(
                  Icons.lock,
                ),
              ),
            ),
            FlatButton(
              color: Colors.lightBlue,
              // textColor: Color(0xFF6200EE),
              onPressed: () async {
                if (passController.text == passController2.text) {
                  BuildContext dialogContext;
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        dialogContext = context;
                        return AlertDialog(
                          title: Text('Mohon tunggu'),
                          content: LinearProgressIndicator(),
                        );
                      });
                  var res =
                      await register(userController.text, passController.text);
                  Navigator.pop(dialogContext);
                  if (res != 'Sukses') {
                    showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text('Message'),
                            content: Text(res),
                          );
                        });
                  } else {
                    Navigator.of(context).pushNamed('/Login');
                  }
                } else {
                  return showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('Message'),
                          content: Text(
                              'Password dan repeated password tidak sesuai'),
                        );
                      });
                }
              }
              // Navigator.of(context).pushNamed('/Login');
              // Respond to button press
              ,
              child: Text("Register"),
            )
          ])),
    );
  }

  void _getTime() {
    final DateTime now = DateTime.now();
    final String formattedDateTime = _formatDateTime(now);
    setState(() {
      _timeString = formattedDateTime;
    });
  }

  String _formatDateTime(DateTime dateTime) {
    return DateFormat('hh:mm:ss').format(dateTime);
  }
}
