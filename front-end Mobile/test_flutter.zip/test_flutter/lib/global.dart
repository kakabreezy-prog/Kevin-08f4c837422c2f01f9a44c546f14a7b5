library test_flutter.globals;

String username = 'asd';
