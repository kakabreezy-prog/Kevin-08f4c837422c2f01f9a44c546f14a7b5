import 'dart:convert';
import 'package:http/http.dart' as http;

Future register(String username, String password) async {
  String apiUrl = "http:/localhost/back-end/register.php";
  final response = await http.post(apiUrl, headers: {
    "Accept": "Application/json"
  }, body: {
    "username": username,
    "password": password,
  });

  var convertedDatatoJson = jsonDecode(response.body);
  return convertedDatatoJson;
}

Future login(String username, String password) async {
  String apiUrl = "http:/localhost/back-end/login.php";
  final response = await http.post(apiUrl, headers: {
    "Accept": "Application/json"
  }, body: {
    "username": username,
    "browser": '',
    "password": password,
  });

  var convertedDatatoJson = jsonDecode(response.body);
  return convertedDatatoJson;
}

Future cek_status(
  String username,
) async {
  String apiUrl = "http://localhost/back-end/cek_status.php";
  final response = await http
      .post(Uri.http("locahost:80", "/back-end/cek_status.php"), headers: {
    "Accept": "Application/json"
  }, body: {
    "username": username,
    "browser": '',
    "tipe": 'Mobile',
  });

  var convertedDatatoJson = jsonDecode(response.body);
  return convertedDatatoJson;
}
